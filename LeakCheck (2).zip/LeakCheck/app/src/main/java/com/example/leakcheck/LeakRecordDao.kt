package com.example.leakcheck

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface LeakRecordDao {
    @Insert
    suspend fun insert(record: LeakRecord)

    @Query("SELECT * FROM leak_records ORDER BY timestamp DESC")
    suspend fun getAll(): List<LeakRecord>
}