package com.example.leakcheck

import android.app.Activity
import android.content.Intent
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat.startActivityForResult
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class RecordActivity : AppCompatActivity() {

    private lateinit var ivPreview: ImageView
    private lateinit var etMemo: EditText
    private lateinit var tvAiResult: TextView

    private var selectedImageUri: Uri? = null
    private var lastLeakPercent = 0
    private var lastAiResult = ""

    companion object {
        private const val REQ_PICK_IMAGE = 1001
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_record)

        ivPreview = findViewById(R.id.ivPreview)
        etMemo = findViewById(R.id.etMemo)
        tvAiResult = findViewById(R.id.tvAiResult)

        val btnSelectImage = findViewById<Button>(R.id.btnSelectImage)
        val btnAnalyze = findViewById<Button>(R.id.btnAnalyze)
        val btnSave = findViewById<Button>(R.id.btnSave)
        val btnBack = findViewById<Button>(R.id.btnBack)

        // 뒤로가기
        btnBack.setOnClickListener {
            finish()
        }

        // 사진 선택
        btnSelectImage.setOnClickListener {
            openGallery()
        }

        // AI 분석
        btnAnalyze.setOnClickListener {
            runAiAnalysis()

        }



        // 결과 저장
        btnSave.setOnClickListener {
            saveResult()
        }
    }
    private fun runAiAnalysis() {

        if (selectedImageUri == null) {
            selectedImageUri = Uri.parse(
                "android.resource://${packageName}/${R.drawable.test_leak}"
            )
        }
        val bitmap = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            ImageDecoder.decodeBitmap(
                ImageDecoder.createSource(contentResolver, selectedImageUri!!)
            )
        } else {
            MediaStore.Images.Media.getBitmap(contentResolver, selectedImageUri)
        }

        ivPreview.setImageBitmap(bitmap)

        val image = InputImage.fromBitmap(bitmap, 0)

        // 🔽 여기부터 AI 분석 코드
        val labeler = ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS)

        labeler.process(image)
            .addOnSuccessListener { labels ->
                var score = 0
                val sb = StringBuilder("AI 분석 결과:\n")

                for (label in labels) {
                    sb.append("- ${label.text} (${(label.confidence * 100).toInt()}%)\n")

                    val t = label.text.lowercase()
                    if (t.contains("water") || t.contains("leak")) score += 30
                    if (t.contains("stain") || t.contains("mold")) score += 25
                    if (t.contains("wall") || t.contains("ceiling")) score += 15
                }

                if (score > 100) score = 100

                lastLeakPercent = score
                lastAiResult = sb.toString()

                sb.append("\n누수 가능성: ${score}%")
                tvAiResult.text = sb.toString()
            }
            .addOnFailureListener {
                tvAiResult.text = "AI 분석 실패"
            }
    }


    private fun openGallery() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        intent.type = "image/*"
        startActivityForResult(intent, REQ_PICK_IMAGE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == REQ_PICK_IMAGE && resultCode == Activity.RESULT_OK) {
            selectedImageUri = data?.data
            ivPreview.setImageURI(selectedImageUri)
        }
    }


    private fun saveResult() {
        if (lastAiResult.isBlank() || selectedImageUri == null) {
            Toast.makeText(this, "AI 분석을 먼저 실행하세요.", Toast.LENGTH_SHORT).show()
            return
        }

        val record = LeakRecord(
            imageUri = selectedImageUri.toString(),
            memo = etMemo.text.toString(),
            aiResult = lastAiResult,
            leakPercent = lastLeakPercent,
            timestamp = System.currentTimeMillis()
        )

        CoroutineScope(Dispatchers.IO).launch {
            AppDatabase.getInstance(this@RecordActivity)
                .leakRecordDao()
                .insert(record)
        }

        Toast.makeText(this, "분석 결과가 저장되었습니다.", Toast.LENGTH_SHORT).show()
    }
}


