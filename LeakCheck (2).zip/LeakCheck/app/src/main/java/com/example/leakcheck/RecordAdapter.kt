package com.example.leakcheck

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.*

class RecordAdapter(
    private val records: List<LeakRecord>
) : RecyclerView.Adapter<RecordAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvPercent: TextView = view.findViewById(R.id.tvPercent)
        val tvDate: TextView = view.findViewById(R.id.tvDate)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_record, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val record = records[position]

        holder.tvPercent.text = "누수 가능성: ${record.leakPercent}%"

        val date = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
            .format(Date(record.timestamp))
        holder.tvDate.text = date

        holder.itemView.setOnClickListener {
            val intent = Intent(holder.itemView.context, LeakResultActivity::class.java)
            intent.putExtra("leakPercent", record.leakPercent)
            intent.putExtra("aiResult", record.aiResult)
            holder.itemView.context.startActivity(intent)
        }
    }

    override fun getItemCount() = records.size
}
