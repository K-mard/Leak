package com.example.leakcheck

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class ReportTemplateActivity : AppCompatActivity(){

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_report_template)

        val etRoom = findViewById<EditText>(R.id.etRoom)
        val etLocation = findViewById<EditText>(R.id.etLocation)
        val etDate = findViewById<EditText>(R.id.etDate)
        val etDetail = findViewById<EditText>(R.id.etDetail)
        val btnGenerate = findViewById<Button>(R.id.btnGenerate)
        val btnCopy = findViewById<Button>(R.id.btnCopy)
        val tvResultText = findViewById<TextView>(R.id.tvResultText)

        val btnBack = findViewById<Button>(R.id.btnBack)
        btnBack.setOnClickListener {
            finish()   // 뒤로가기: 이전 화면으로 복귀
        }

        // 신고 문구 생성
        btnGenerate.setOnClickListener {
            val room = etRoom.text.toString().ifBlank { "호수 미기재" }
            val location = etLocation.text.toString().ifBlank { "누수 위치 미기재" }
            val date = etDate.text.toString().ifBlank { "날짜 미기재" }
            val detail = etDetail.text.toString().ifBlank { "추가 설명 없음" }

            val template = """
                안녕하세요, $room 거주자입니다.

                $date 경부터 집 안의 [$location] 부근에서 누수로 의심되는 증상이 발생하여 연락드립니다.

                상세 상황:
                - $detail

                확인 후 조치 부탁드립니다.
                감사합니다.
            """.trimIndent()

            tvResultText.text = template

        }

        // 클립보드에 복사
        btnCopy.setOnClickListener {
            val textToCopy = tvResultText.text.toString()
            if (textToCopy.isBlank()) {
                Toast.makeText(this, "먼저 신고 문구를 생성해 주세요.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }


            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText("누수 신고 문구", textToCopy)
            clipboard.setPrimaryClip(clip)

            Toast.makeText(this, "클립보드에 복사되었습니다. 카톡/문자에 붙여넣기 하세요.", Toast.LENGTH_SHORT).show()
        }
    }
}