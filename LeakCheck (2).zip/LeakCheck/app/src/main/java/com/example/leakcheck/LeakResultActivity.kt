package com.example.leakcheck

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class LeakResultActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_leak_result)

        val tvLeakPercent = findViewById<TextView>(R.id.tvLeakPercent)
        val tvAdvice = findViewById<TextView>(R.id.tvAdvice)
        val btnBackToMain = findViewById<Button>(R.id.btnBackToMain)



        val leakPercent = intent.getIntExtra("leakPercent", 0)

        // % 표시
        tvLeakPercent.text = "누수 가능성: ${leakPercent}%"

        // %에 따른 조언 문구
        val adviceText = when {
            leakPercent >= 70 -> "누수 가능성이 매우 높습니다.\n즉시 집주인/관리실에 연락하는 것을 추천합니다."
            leakPercent >= 40 -> "누수 가능성이 중간 정도입니다.\n상황을 기록하면서 지켜보세요."
            leakPercent > 0 -> "누수 가능성은 낮습니다.\n하지만 이상 징후가 생기면 바로 기록하는 것이 좋습니다."
            else -> "증상이 없으므로 누수 가능성이 매우 낮습니다."
        }
        tvAdvice.text = adviceText

        btnBackToMain.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            startActivity(intent)
            finish()
        }
    }
}