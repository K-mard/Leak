package com.example.leakcheck

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import androidx.appcompat.app.AppCompatActivity


class DiagnosisActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_diagnosis)

        val cbCeilingStain = findViewById<CheckBox>(R.id.cbCeilingStain)
        val cbWallBubble = findViewById<CheckBox>(R.id.cbWallBubble)
        val cbWetFloor = findViewById<CheckBox>(R.id.cbWetFloor)
        val cbRainWorse = findViewById<CheckBox>(R.id.cbRainWorse)
        val cbMoldSmell = findViewById<CheckBox>(R.id.cbMoldSmell)
        val btnCalculate = findViewById<Button>(R.id.btnCalculate)

        btnCalculate.setOnClickListener {
            val leakPercent = calculateLeakProbability(
                hasCeilingStain = cbCeilingStain.isChecked,
                hasWallBubble = cbWallBubble.isChecked,
                hasWetFloor = cbWetFloor.isChecked,
                worseWhenRaining = cbRainWorse.isChecked,
                hasMoldSmell = cbMoldSmell.isChecked
            )

            val intent = Intent(this, LeakResultActivity::class.java)
            intent.putExtra("leakPercent", leakPercent)
            startActivity(intent)
        }
    }

    private fun calculateLeakProbability(
        hasCeilingStain: Boolean,
        hasWallBubble: Boolean,
        hasWetFloor: Boolean,
        worseWhenRaining: Boolean,
        hasMoldSmell: Boolean
    ): Int {
        var score = 0

        if (hasCeilingStain) score += 30
        if (hasWallBubble) score += 25
        if (hasWetFloor) score += 25
        if (worseWhenRaining) score += 15
        if (hasMoldSmell) score += 10

        if (score > 100) score = 100

        return score
    }


}