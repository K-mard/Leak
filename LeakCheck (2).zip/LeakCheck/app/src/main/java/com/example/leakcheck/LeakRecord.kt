package com.example.leakcheck
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "leak_records")

data class LeakRecord (
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,

    val imageUri: String,
    val memo: String,
    val aiResult: String,
    val leakPercent: Int,
    val timestamp: Long
)
